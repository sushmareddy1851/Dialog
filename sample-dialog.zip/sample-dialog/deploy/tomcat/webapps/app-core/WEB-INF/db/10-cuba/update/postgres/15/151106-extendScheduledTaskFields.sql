alter table SYS_SCHEDULED_TASK alter column PERMITTED_SERVERS type varchar(4096)^
alter table SYS_SCHEDULED_TASK alter column LAST_START_SERVER type varchar(512)^
alter table SYS_SCHEDULED_EXECUTION alter column SERVER type varchar(512)^

