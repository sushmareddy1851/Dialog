-- Description: adding SEC_USER.IP_MASK

alter table SEC_USER add column IP_MASK varchar(200);