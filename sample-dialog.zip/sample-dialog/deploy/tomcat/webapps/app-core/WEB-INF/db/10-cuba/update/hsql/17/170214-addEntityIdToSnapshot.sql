alter table SYS_ENTITY_SNAPSHOT add STRING_ENTITY_ID varchar(255)^
alter table SYS_ENTITY_SNAPSHOT add INT_ENTITY_ID integer^
alter table SYS_ENTITY_SNAPSHOT add LONG_ENTITY_ID bigint^