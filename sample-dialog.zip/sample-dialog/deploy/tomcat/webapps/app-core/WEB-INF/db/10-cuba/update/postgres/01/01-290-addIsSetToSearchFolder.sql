-- Description
alter table SEC_SEARCH_FOLDER add column IS_SET boolean;
alter table SEC_SEARCH_FOLDER add column ENTITY_TYPE varchar(50);
