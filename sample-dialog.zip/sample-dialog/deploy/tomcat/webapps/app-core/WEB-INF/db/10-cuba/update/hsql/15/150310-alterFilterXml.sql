-- Change SEC_FILTER.XML to Lob

alter table SEC_FILTER alter XML longvarchar;
