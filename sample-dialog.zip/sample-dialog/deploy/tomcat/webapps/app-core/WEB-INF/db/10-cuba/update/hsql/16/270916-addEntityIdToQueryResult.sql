alter table SYS_QUERY_RESULT add STRING_ENTITY_ID varchar(255)^
alter table SYS_QUERY_RESULT add INT_ENTITY_ID integer^
alter table SYS_QUERY_RESULT add LONG_ENTITY_ID bigint^
