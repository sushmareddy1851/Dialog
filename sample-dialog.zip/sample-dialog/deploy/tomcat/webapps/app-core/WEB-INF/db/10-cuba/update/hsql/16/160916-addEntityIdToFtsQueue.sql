alter table SYS_FTS_QUEUE add STRING_ENTITY_ID varchar(255)^
alter table SYS_FTS_QUEUE add INT_ENTITY_ID integer^
alter table SYS_FTS_QUEUE add LONG_ENTITY_ID bigint^