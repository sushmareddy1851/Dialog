alter table SYS_CATEGORY_ATTR add IS_COLLECTION char(1)^
alter table SYS_ATTR_VALUE add PARENT_ID varchar2(32)^