-- Description:
--  * Add to 'REPORT_INPUT_PARAMETER' column 'ENUM_CLASS'

alter table REPORT_INPUT_PARAMETER add column ENUM_CLASS varchar(500);