package com.company.sampledialog.web.test;

import com.company.sampledialog.entity.Test;
import com.haulmont.cuba.gui.WindowManager;
import com.haulmont.cuba.gui.components.AbstractLookup;
import com.haulmont.cuba.gui.components.CheckBox;
import com.haulmont.cuba.gui.components.DataGrid;
import com.haulmont.cuba.gui.components.PopupView;
import com.haulmont.cuba.gui.components.actions.CreateAction;
import com.haulmont.cuba.gui.components.actions.EditAction;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Map;

public class TestBrowse extends AbstractLookup {

    @Inject
    private DataGrid<Test> testsTable;

    @Inject
    private PopupView CheckboxPopupView;

    @Inject
    private CheckBox forSameReasonCheckBox;

    @Named("testsTable.create")
    private CreateAction create;
    @Named("testsTable.edit")
    private EditAction edit;

    private boolean checkBoxFlag = false;

    @Override
    public void init(Map<String, Object> params){
        testsTable.addSelectionListener(event -> {

        });
        testsTable.addEditorPreCommitListener(event -> {

        });
        testsTable.addEditorPostCommitListener(event -> {

        });
        forSameReasonCheckBox.addValueChangeListener(event -> {

            
            if (Boolean.TRUE.equals(event.getValue())) {
                checkBoxFlag = true;
//                createContentForCheckBox();

            } else {
                checkBoxFlag=false;
//                savePlanningView();
            }
        });
        testsTable.addEditorCloseListener(event -> {
            CheckboxPopupView.setPopupVisible(true);
            openWindow("screen", WindowManager.OpenType.DIALOG);
        });
    }



}