package com.company.sampledialog.web.test;

import com.haulmont.cuba.gui.components.AbstractEditor;
import com.company.sampledialog.entity.Test;

public class TestEdit extends AbstractEditor<Test> {
}