package com.company.sampledialog.web.screens;

import com.haulmont.cuba.gui.components.AbstractWindow;

public class Screen extends AbstractWindow {
}